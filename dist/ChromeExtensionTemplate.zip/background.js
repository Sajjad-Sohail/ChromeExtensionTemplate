﻿'use strict';

chrome.runtime.onInstalled.addListener(function () {
    console.log("Extension is loaded.");
});